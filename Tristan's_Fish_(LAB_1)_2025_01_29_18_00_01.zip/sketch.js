function setup() {
  createCanvas(400, 400);
}

function draw() {
  //water
  background("hsl(200,75%,75%)")
  
  //sand
  noStroke()
  fill("hsl(50,50%,75%)")
  rect(0,300,400,400)
  
  //FISH 1
  stroke('black')
  strokeWeight(2)
    //body
  fill("hsl(130,50%,75%)")
  ellipse(150,100,100,75)
    //tail
  fill("hsl(130,50%,65%)")  
  triangle(201,100,240,75,240,125)
    //eye
  fill("hsl(130,50%,100%)")
  ellipse(130,95,25,25)
  fill(0)
  ellipse(130,95,13,13)
    //mouth
  noFill()
  arc(110,110,50,50,13,1)
  
  //FISH 2
  //body
  fill("hsl(320,50%,70%)")
  ellipse(280,235,150,80)
    //tail
  fill("hsl(320,50%,60%)")  
  triangle(205,235,180,270,180,200)
    //eye
  fill("hsl(130,50%,100%)")
  ellipse(315,230,25,25)
  fill(0)
  ellipse(315,230,18,9)
    //mouth
  line(325,255,345,255)
  line(325,255,315,253)
  
  
}

//rect,square,ellipse,quad,triangle

//line, angleMode, arc